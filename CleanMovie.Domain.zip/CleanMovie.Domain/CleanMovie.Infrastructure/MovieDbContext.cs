﻿using CleanMovie.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanMovie.Infrastructure
{
    public class MovieDbContext : DbContext
    {
        public MovieDbContext(DbContextOptions<MovieDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // one to many (Member and Rental)

            modelBuilder.Entity<Member>()
                .HasOne<Rental>(s => s.rental)
                .WithMany(r => r.members)
                .HasForeignKey(s => s.RentalId);

            // many to many (Rental and Movies)
            modelBuilder.Entity<MoviesRental>()
             .HasKey(s => new { s.MovieId,s.RentalId});

            // Handle decimal to prsion loss

            modelBuilder.Entity<Rental>()
                .Property(s => s.TotalCost)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Movie>()
                .Property(s => s.RenatlCost)
                .HasColumnType("decimal(18,2)");

        }


        public DbSet<Movie> Movies { get; set; }
        public DbSet<Rental> rentals { get; set; }
        public DbSet<Member> members { get; set; }
        public DbSet<MoviesRental> MoviesRentals { get; set; }
    }
}
