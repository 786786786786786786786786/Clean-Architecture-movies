﻿namespace CleanMovie.Domain
{
    public class MoviesRental
    {
        public int RentalId { get; set; }
        public int MovieId { get; set; }
    }
}